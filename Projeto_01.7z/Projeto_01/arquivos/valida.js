const fs = require('fs');
const axios = require('axios');

const validateLinks = async (markdownFile) => {
  // Ler o conteúdo do arquivo Markdown
  const markdownContent = fs.readFileSync(markdownFile, 'utf-8');

  // Encontrar todos os links usando uma expressão regular
  const linkRegex = /\[([^\]]+)\]\((http[s]?:\/\/[^\)]+)\)/g;
  const links = [];
  let match;
  while ((match = linkRegex.exec(markdownContent))) {
    links.push(match[2]);
  }

  if (links.length === 0) {
    throw new Error("Esse arquivo não apresenta nenhum link");
  }
  // Fazer uma requisição HTTP para cada URL e verificar o status da resposta
  const linkStatuses = await Promise.all(
    links.map(async (link) => {
      try {
        const response = await axios.get(link);
        return { link, status: response.status };
      } catch (error) {
        
        return { link, status: error.response.status };
      }
    })
  );

  // Retornar a lista de URLs e seus respectivos status HTTP
  return linkStatuses;
};

// Exemplo de uso: validar os links em um arquivo Markdown e imprimir a lista de URLs e seus status HTTP
validateLinks(process.argv[2])
  .then((linkStatuses) => {
  console.log(linkStatuses);
})


